import pygame
import random

pygame.init()

width = 800
height = 600
white = (255, 255, 255)
black = (0, 0, 0)
gray = (128, 128, 128)
red = (255, 0, 0)
large_font = pygame.font.Font("freesansbold.ttf", 24)
small_font = pygame.font.Font("freesansbold.ttf", 18)
fps = 60
time = pygame.time.Clock()

rows = 7
columns = 7
number_of_spaces = rows*columns
types = ["paper", "plastic", "metal", "glass"]
number_of_rubbish = 15
score_target = 50
turns = 4

new_board = True                                #this variable stores whether or not a board needs to be created
piece_picked = False                            #this variable stores whether or not the player has picked a piece to move
selected_piece = None                           #this variable stores the location(0 to number_of_spaces-1) of the selected piece
task = types[random.randint(0,len(types)-1)]    #this variabel stores the type of piece they must match in order to remove another piece of rubbish
score = 0
final_screen = False


#this function assigns each piece on the board a type, and ensures none of the pieces are in a row of 3 or more
def create_board():
    global spaces
    spaces = []                                 #this variable stores the type of each piece on the board
    for i in range(number_of_rubbish+1):        #the required amount of rubbish is added to the board
        spaces.append("rubbish")
    #the next 4 lines add the list "types" to "spaces", until spaces is full(len(spaces) == number_of_spaces)
    while len(spaces) + len(types) < number_of_spaces:
        spaces.extend(types)
    if len(spaces) < number_of_spaces:
        spaces.extend(types[:number_of_spaces - len(spaces)])
    random.shuffle(spaces)              #the pieces are shuffled, in order to create a different, random, board each game

    no_matches = False                  #this variable stores whether the current board has any matching pieces that need to be moved
    while no_matches == False:          #if there is a match, this function will attempt to fix it, before checking again
        no_matches = True               #no_matches is assumed true, until shown to be false
        for i in range(0, len(spaces) - 2):

            #this is the first part of the check, checking below each piece
            if (i+2) % 7 == 0 or (i+1) % 7 == 0:    #the last 2 pieces on each column do not need to be checked, as each piece checks the 2 below it
                continue
            if spaces[i] == spaces[i+1] and spaces[i] == spaces[i+2]: #if 3 in a row
                #this section attempts to swap one of the pieces with one higher on the list
                if i+7 <= number_of_spaces-1:     #if the piece being checked is not in the last 7
                    if spaces[i] != spaces[i+4]:
                        spaces[i], spaces[i+4] = spaces[i+4], spaces[i]
                    elif spaces[i+1] != spaces[i+5]:
                        spaces[i+1], spaces[i+5] = spaces[i+5], spaces[i+1]
                    elif spaces[i+2] != spaces[i+7]:
                        spaces[i+2], spaces[i+7] = spaces[i+2], spaces[i+7]
                    else:                       #if none of theses solutions work, the board is reshuffled
                        random.shuffle(spaces)
                        no_matches = False
                #this section attempts to swap one of the pieces with one lower on the list
                elif i>=4:                      #if the piece being checked is not in the first 3
                    if spaces[i] != spaces[i-1]:
                        spaces[i], spaces[i-1] = spaces[i-1], spaces[i]
                        no_matches = False
                    elif spaces[i+1] != spaces[i-2]:
                        spaces[i+1], spaces[i-2] = spaces[i-2], spaces[i+1]
                        no_matches = False
                    elif spaces[i+2] != spaces[i-4]:
                        spaces[i+2], spaces[i-4] = spaces[i+2], spaces[i-4]
                        no_matches = False
                    else:                       #if none of theses solutions work, the board is reshuffled
                        random.shuffle(spaces)
                        no_matches = False
                else:                           #if none of theses solutions work, the board is reshuffled
                    random.shuffle(spaces)
                    no_matches = False

        #this is the second part of the check, checking to the left and right of each piece
        for i in range(0, len(spaces) - 2*rows):    #the last 2 columns do not need to be checked, as each piece checks the 2 to the right
            if spaces[i] == spaces[i+rows] and spaces[i] == spaces[i+2*rows]: #if 3 in a row
                #this section attempts to swap one of the pieces with one higher on the list
                if (i+2*rows+2) <= number_of_spaces:    #if the piece being checked is not in the last 2 columns
                    if spaces[i] != spaces[i+1]:
                        spaces[i], spaces[i+1] = spaces[i+1], spaces[i]
                        no_matches = False
                    elif spaces[i+rows] != spaces[i+rows+1]:
                        spaces[i+rows], spaces[i+rows+1] = spaces[i+rows+1], spaces[i+rows]
                        no_matches = False
                    elif spaces[i+2*rows] != spaces[i+2*rows+1]:
                        spaces[i+2*rows], spaces[i+2*rows+1] = spaces[i+2*rows+1], spaces[i+2*rows]
                        no_matches = False
                    else:                       #if none of theses solutions work, the board is reshuffled
                        random.shuffle(spaces)
                        no_matches = False
                #this section attempts to swap one of the pieces with one lower on the list
                elif i>=1:                              #if the piece being checked is not the first
                    if spaces[i] != spaces[i-1]:
                        spaces[i], spaces[i-1] = spaces[i-1], spaces[i]
                        no_matches = False
                    elif spaces[i+rows] != spaces[i+rows-1]:
                        spaces[i+rows], spaces[i+rows-1] = spaces[i+rows-1], spaces[i+rows]
                        no_matches = False
                    elif spaces[i+2*rows] != spaces[i+2*rows-1]:
                        spaces[i+2*rows], spaces[i+2*rows-1] = spaces[i+2*rows-1], spaces[i+2*rows]
                        no_matches = False
                    else:                       #if none of theses solutions work, the board is reshuffled
                        random.shuffle(spaces)
                        no_matches = False
                else:                           #if none of theses solutions work, the board is reshuffled
                    random.shuffle(spaces)
                    no_matches = False



def draw_background():
    board = pygame.draw.rect(screen, gray, [250, 0, width-250, height], 0)      #the gray background on the right
    left_banner = pygame.draw.rect(screen, black, [0, 0, 250, height])          #the black background on the left
    title = large_font.render("Sort the Recycling", True, white)
    text_rect = title.get_rect(center=(125, 50))
    screen.blit(title, text_rect)
    target_text = small_font.render(f"Target points: {score_target}", True, white)
    target_rect = target_text.get_rect(center=(125, 150))
    screen.blit(target_text, target_rect)



def draw_board():
    board_list = []

    #this section draws the pieces and their white backgrounds
    for i in range(columns):
        for j in range(rows):
            piece = pygame.draw.rect(screen, white, [i*70 + 280,  j*70 + 60, 70, 70], 0, 4)
            board_list.append(piece)
            piece_image = pygame.image.load(f"assets/{spaces[i*rows + j]}.png")
            screen.blit(piece_image, (i*70 + 280, j*70 + 60))
    
    if piece_picked == True:        #if the player has selected a piece, it is highlighted in red
        pygame.draw.rect(screen, red, (board_list[selected_piece][0], board_list[selected_piece][1], 70, 70), 5)
    score_text = small_font.render(f"Score: {score}", True, white)
    text_rect = score_text.get_rect(center=(125, 100))
    screen.blit(score_text, text_rect)
    turns_text = small_font.render(f"Turns remaining: {turns}", True, white)
    turns_rect = turns_text.get_rect(center=(125, 200))
    screen.blit(turns_text, turns_rect)
    task_text = small_font.render(f"Your current task is: {task}", True, white)
    task_rect = task_text.get_rect(center=(125, 250))
    screen.blit(task_text, task_rect)
    if task == None:
        remove1_text = small_font.render("Select a piece of rubbish", True, white)
        remove1_rect = remove1_text.get_rect(center=(125, 300))
        screen.blit(remove1_text, remove1_rect)
        remove2_text = small_font.render("to remove", True, white)
        remove2_rect = remove2_text.get_rect(center=(125, 320))
        screen.blit(remove2_text, remove2_rect)
    return board_list



#this function checks if there are any 3-in-a-rows, and if so gives points and replaces them
def three_check(check_piece):
    global score
    global task
    vertical = vertical_check(check_piece)
    horizontal = horizontal_check(check_piece)
    if vertical[0] >= 2 and horizontal[0] >= 2:
        #this if statement checks if the player has completed their task
        if spaces[vertical[1][0]] == task:
            task = None
        vertical[1].pop()       #due to both vertical and horizontal being included, this stops the initial piece from being duplicated
        replaced = replace(vertical[1] + horizontal[1])
        for i in range(0, len(replaced)):
            three_check(replaced[i])
        score+=5                        #5 points for a T or L shape
    elif vertical[0] >= 3:
        if spaces[vertical[1][0]] == task:
           task = None
        replaced = replace(vertical[1])
        for i in range(0, len(replaced)):
            three_check(replaced[i])
        score+=3                        #3 points for >3 in a row
    elif horizontal[0] >= 3:
        if spaces[horizontal[1][0]] == task:
            task = None
        replaced = replace(horizontal[1])
        for i in range(0, len(replaced)):
            three_check(replaced[i])
        score+=3                        #3 points for >3 in a row
    elif vertical[0] >= 2:
        if spaces[vertical[1][0]] == task:
            task = None
        replaced = replace(vertical[1])
        for i in range(0, len(replaced)):
            three_check(replaced[i])
        score+=1                        #1 point for 3 in a row
    elif horizontal[0] >= 2:
        if spaces[horizontal[1][0]] == task:
            task = None
        replaced = replace(horizontal[1])
        for i in range(0, len(replaced)):
            three_check(replaced[i])
        score+=1                        #1 point for 3 in a row
    



#this function checks above and below the selected piece, to see if it is 3 in a row, or more
def vertical_check(check_piece):#
    #if the piece being checked is rubbish, it will not be counted as 3 in row
    if spaces[check_piece] == "rubbish":
        return 0, []
    else:
        down = 0
        up = 0
        pieces_list = []
        for i in range(1, 5):
            if check_piece+i <= number_of_spaces and (check_piece)%7 < (check_piece+i)%7:
                if spaces[check_piece] == spaces[check_piece+i] and (down+1) == i:
                    down+=1
                    pieces_list.append(check_piece+i)
            if check_piece-i >= 0 and (check_piece)%7 > (check_piece-i)%7 and (up+1) == i:
                if spaces[check_piece] == spaces[check_piece-i]:
                    up+=1
                    pieces_list.append(check_piece-i)
        total = down + up
        if total >= 2:
            pieces_list.append(check_piece)
        return total, pieces_list
    
    

#this function checks to the left and right of the selected piece, to see if it is 3 in a row, or more
def horizontal_check(check_piece):
    #if the piece being checked is rubbish, it will not be counted as 3 in row
    if spaces[check_piece] == "rubbish":
        return 0, []
    else:
        right = 0
        left = 0
        pieces_list = []
        for i in range(1, 5):
            if (check_piece+(i*rows)+1) <= number_of_spaces:
                if spaces[check_piece] == spaces[check_piece+(i*rows)] and (right+1) == i:
                    right+=1
                    pieces_list.append(check_piece+(i*rows))
            if check_piece-(i*rows) >= 0:
                if spaces[check_piece] == spaces[check_piece-(i*rows)] and (left+1) == i:
                    left+=1
                    pieces_list.append(check_piece-(i*rows))
        total = right + left
        if total >= 2:
            pieces_list.append(check_piece)
        return total, pieces_list



#this function randomly replaces pieces after they have been placed 3 in row
def replace(replace_pieces):
    global last_replace_time
    last_replace_time = pygame.time.get_ticks()
    #the game waits 1 second before replacing the pieces, so the player can see and comprehend what happens
    while pygame.time.get_ticks() - last_replace_time < 1000:
        time.tick(fps)
        screen.fill(white)
        draw_background()
        draw_board()
        pygame.display.flip()
    for i in range(0,len(replace_pieces)):
        replaced = False
        while not replaced:
            replacement = types[random.randint(0,len(types)-1)]
            if replacement != spaces[replace_pieces[i]]:
                spaces[replace_pieces[i]] = replacement
                replaced = True
    return(replace_pieces)




create_board()
screen = pygame.display.set_mode([width, height])
pygame.display.set_caption("Sort the Reycling")
running = True

while running:
    global last_replace_time 
    time.tick(fps)
    screen.fill(white)
    if new_board:
        create_board()
        new_board = False

    draw_background()
    board = draw_board()
    
    for event in pygame.event.get():

        if event.type == pygame.QUIT:       #allows the player to turn off the game
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:    #if the player clicks the mouse

            #this section checks if the player had the mouse over a piece when they clicked down
            for i in range(0, len(board)):
                button = board[i]

                #this section removes a piece of rubbish, if the player has the ability to and clicked on rubbish
                if button.collidepoint(event.pos) and task == None:
                    if spaces[i] == "rubbish":
                        replace([i])
                        three_check(i)
                        task = types[random.randint(0,len(types)-1)]
                        if turns == 0:
                            last_replace_time = pygame.time.get_ticks()
                            while pygame.time.get_ticks() - last_replace_time < 1000:
                                time.tick(fps)
                                screen.fill(white)
                                draw_background()
                                draw_board()
                                pygame.display.flip()
                            
                            final_screen = True

                #this section picks a piece to move, if the player has clicked on one, and has not already selected a piece
                elif button.collidepoint(event.pos) and not piece_picked:
                    piece_picked = True
                    selected_piece = i

                #this section picks which piece to swap with the selected piece, if the player has already selected a piece, and it is adjacent    
                elif button.collidepoint(event.pos) and piece_picked:
                    piece_picked = False
                    if selected_piece in {i+1, i-1, i+rows, i-rows}:        #if the new piece is adjacent to the previously selected piece
                        spaces[i], spaces[selected_piece] = spaces[selected_piece], spaces[i]
                        three_check(i)
                        three_check(selected_piece)
                        turns-=1

                        #ends the game after the player hashad their last turn
                        if turns == 0 and task != None:
                            last_replace_time = pygame.time.get_ticks()
                            while pygame.time.get_ticks() - last_replace_time < 1000:
                                time.tick(fps)
                                screen.fill(white)
                                draw_background()
                                draw_board()
                                pygame.display.flip()
                            
                            final_screen = True
        while final_screen:
            if score >= score_target:
                final_text = small_font.render("You won, thank you for playing. Press SPACE to quit.", True, black)
            else:
                final_text = small_font.render("You failed, thank you for playing. Press SPACE to quit.", True, black)
            text_rect = final_text.get_rect(center=(width/2, height/2))
            screen.fill(gray)  # Fill background
            screen.blit(final_text, text_rect)  # Draw text
            pygame.display.flip()  # Update display
            for event in pygame.event.get():
                if event.type == pygame.QUIT:       #allows the player to turn off the game using the quit button
                    pygame.quit()
                    exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE: #allows the player to turn off the game using the space button
                        pygame.quit()
                        exit()



    pygame.display.flip()
pygame.quit()